# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 10:38:30 2015

@author: chris
"""



global root 
ioff()    
root = Tk()
FittingWindow(root)

root.mainloop()
  
  
